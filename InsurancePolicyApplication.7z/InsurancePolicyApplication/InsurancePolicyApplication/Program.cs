﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

//Joshua McAdams
//13/11/2016
//A form designed for the input of up to 5 drivers' details into an insurance policy.
//Validation occurs on this inputs and, if they pass, a premium is calculated based on certain rules.
//If the policy fails validation, it will display reasons for the driver(s) with their names appended.

namespace InsurancePolicyApplication
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmPolicyStart());
        }
    }
}
