﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePolicyApplication
{
    public class Driver
    {
        private string name;
        private DateTime dateOfBirth;
        private int numberOfClaims;
        private string occupation;

        public Driver(string name, DateTime dateOfBirth, int numberOfClaims, string occupation)
        {
            this.name = name;
            this.dateOfBirth = dateOfBirth;
            this.numberOfClaims = numberOfClaims;
            this.occupation = occupation;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public DateTime DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }

        public int NumberOfClaims
        {
            get { return numberOfClaims; }
            set { numberOfClaims = value; }
        }

        public string Occupation
        {
            get { return occupation; }
            set { occupation = value; }
        }

        //Calculates the drivers age from DateTime and converts it into an age value, which is what the policy will work with.
        public int CalculateAge(DateTime startDate)
        {
            int age = startDate.Year - dateOfBirth.Year;
            if (startDate.Month < dateOfBirth.Month || (startDate.Month == dateOfBirth.Month && startDate.Day < dateOfBirth.Day))
                age--;
            return age;
        }

        public string ShowDetails()
        {
            string message = "Driver name: " + name + "\tDriver DOB " + dateOfBirth + "\tNumber of claims" + numberOfClaims + "\tOccupation" + occupation;
            return message;
        }

    }
}
