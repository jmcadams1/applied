﻿namespace InsurancePolicyApplication
{
    partial class frmPolicyStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPolicy = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmdEnterDate = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPolicy
            // 
            this.lblPolicy.AutoSize = true;
            this.lblPolicy.Location = new System.Drawing.Point(76, 180);
            this.lblPolicy.Name = "lblPolicy";
            this.lblPolicy.Size = new System.Drawing.Size(196, 13);
            this.lblPolicy.TabIndex = 0;
            this.lblPolicy.Text = "Please enter the start date of your policy";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(368, 180);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 1;
            // 
            // cmdEnterDate
            // 
            this.cmdEnterDate.Location = new System.Drawing.Point(283, 242);
            this.cmdEnterDate.Name = "cmdEnterDate";
            this.cmdEnterDate.Size = new System.Drawing.Size(75, 23);
            this.cmdEnterDate.TabIndex = 2;
            this.cmdEnterDate.Text = "Enter";
            this.cmdEnterDate.UseVisualStyleBackColor = true;
            this.cmdEnterDate.Click += new System.EventHandler(this.cmdEnterDate_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(92, 27);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(444, 26);
            this.lblWelcome.TabIndex = 3;
            this.lblWelcome.Text = "Welcome to the Insurance Premium Calculator.\r\nThis will allow you to calculate a " +
    "premium for a policy of up to 5 drivers.  To begin, see below.";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frmPolicyStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 311);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.cmdEnterDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lblPolicy);
            this.Name = "frmPolicyStart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Premium Calculator - Policy Start Date Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPolicy;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Button cmdEnterDate;
        private System.Windows.Forms.Label lblWelcome;
    }
}