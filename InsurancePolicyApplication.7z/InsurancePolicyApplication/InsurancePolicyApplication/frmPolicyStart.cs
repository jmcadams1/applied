﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsurancePolicyApplication
{
    public partial class frmPolicyStart : Form
    {
        DateTime startDate;

        public frmPolicyStart()
        {
            InitializeComponent();
        }

        //Passes start date to main form after validating that the start date is in the future.
        private void cmdEnterDate_Click(object sender, EventArgs e)
        {
            startDate = dtpStartDate.Value.Date;
            if (startDate >= DateTime.Today)
            {
                Form detailsEntry = new frmEntry(startDate);
                detailsEntry.ShowDialog();
                dtpStartDate.Value = DateTime.Today;
            }
            else
            {
                MessageBox.Show("Error: Start Date of Policy");
                dtpStartDate.Value = DateTime.Today;
            }
        }
    }
}

