﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsurancePolicyApplication
{
    public partial class frmEntry : Form
    {
        private int totalPolicyClaims = 0;
        private int remainingClaims;
        private int driverCount = 0;
        private double percentage = 1;
        private string occupation = "";
        private DateTime currentDate = DateTime.Now;
        private DateTime startDate;
        private List<Driver> driver;
        private List<DateTime> claimDates;

        public frmEntry(DateTime startDate)
        {
            InitializeComponent();
            this.startDate = startDate;
            lblStartDate.Text = "Start date of policy: " + startDate.Day.ToString() + "/" + startDate.Month.ToString() + "/" + startDate.Year.ToString();
            driver = new List<Driver>();
            claimDates = new List<DateTime>();
        }

        //If data entry passes, puts up the driver count and is hidden once the maximum amount of drivers is input.
        private void cmdEnter_Click(object sender, EventArgs e)
        {
            if (driverCount == 4)
            {
                MessageBox.Show("You have reached the maximum amount of drivers on this policy");
                cmdEnter.Visible = false;
                cmdEnter.Hide();
            }
            driverCount++;
            AddDriver();
            occupation = "";
        }

        //Provides occupation for driver object
        private void optChauffeur_CheckedChanged(object sender, EventArgs e)
        {
            occupation = "Chauffeur";
        }

        //Provides occupation for driver object
        private void optAccountant_CheckedChanged(object sender, EventArgs e)
        {
            occupation = "Accountant";
        }

        //Assigns all the data entered into the form to a driver object, which is stored in a driver list.
        //Also supplies user with feedback on how many drivers  have been entered.
        public void AddDriver()
        {
            try
            {
                driver.Add(new Driver("", DateTime.Today, 0, ""));

                if (Regex.IsMatch(txtName.Text, @"^[a-z, A-Z, \-, ']+$"))
                {
                    driver[driverCount - 1].Name = txtName.Text.ToString();
                }
                else
                {
                    throw new Exception();
                }

                driver[driverCount - 1].Occupation = occupation;
                if (driver[driverCount - 1].Occupation == "")
                {
                    throw new Exception();
                }

                driver[driverCount - 1].DateOfBirth = dtpDOB.Value.Date;

                driver[driverCount - 1].NumberOfClaims = Convert.ToInt32(lstClaims.Text);

                totalPolicyClaims += Convert.ToInt32(lstClaims.Text);

                if (driver[driverCount - 1].NumberOfClaims > 0)
                {
                    remainingClaims = driver[driverCount - 1].NumberOfClaims;
                    ShowClaimEntry();
                    MessageBox.Show("Please enter the dates of your " + remainingClaims + " claims.");
                }

                lblDriverNumber.Text = "You have entered details for " + driverCount + "/5 drivers.";

                if (driverCount > 0 && remainingClaims == 0)
                {
                    cmdPremium.Visible = true;
                    cmdPremium.Show();
                }

                if (driver[driverCount - 1].NumberOfClaims == 0)
                    ResetFields();
            }
            //Ensures that if an exception is caught that the erroneous details for the driver are removed and the drivercount is corrected
            //Also ensures a null value added by not selecting a claim from the list is handled.
            catch (Exception)
            {
                MessageBox.Show("Error Message\nYou have either: \nNot fully filled out form. \nUsed invalid characters in the name field.");
                driver.Remove(driver[driverCount - 1]);
                driverCount--;
                lblDriverNumber.Text = "You have entered details for " + driverCount + "/5 drivers.";

            }
        }

        //Performs the decline checks, and if nothing has been declined proceeds to display premium.
        //Calculates a base premium from an amount of 500 by applying a calculated percentage value to it based on the rules.
        //Displays the premium to the user and resets the application.
        private void cmdPremium_Click(object sender, EventArgs e)
        {
            string declineMessage = "";

            declineMessage += DeclineMessageAge();
            declineMessage += DeclineMessageDriverClaims();
            declineMessage += DeclineMessageTotalClaims();

            if (declineMessage == "")
            {
                double premium = 500;
                PremiumOccupation();
                PremiumAge();
                PremiumClaims();

                premium *= percentage;

                MessageBox.Show("Your calculated premium is £" + premium.ToString("#.##"));
                this.Close();
            }
            else
            {
                MessageBox.Show("Policy has been declined for the following reasons:\n" + declineMessage);
                this.Close();
            }
        }

        //Calculates a percentage value based on the occupation selected
        //Decreases it by 10%(0.9) if Accountant is selected
        //Increases it by 10%(1.1) if Chauffeur is selected

        private void PremiumOccupation()
        {
            foreach (Driver driver in driver)
            {
                if (driver.Occupation == "Accountant")
                {
                    percentage *= 0.9;
                }
                if (driver.Occupation == "Chauffeur")
                {
                    percentage *= 1.1;
                }
            }
        }

        /*
         * Calculates a percentage value based on the age of the youngest driver in the policy
         * Increases the percentage by 20%(1.2) if the youngest driver is within 21-25 years 
         * Decreases by 10%(0.9) if they are between 26-75 (Policy does not go through if they are >75)
         */
        private void PremiumAge()
        {
            bool youngestDiscount;
            youngestDiscount = YoungestDriverCheck(driver, startDate);
            if (youngestDiscount)
            {
                percentage = percentage * 0.9;
            }
            if (!youngestDiscount)
            {
                percentage = percentage * 1.2;
            }
        }

        /* 
         * Calculates a percentage value based on the dates of claims.
         * If the date of a claim is within 1 year of the start date of the policy it will increase by 20% (1.2)
         * If the date of a claim is within 2-5 years of the start date of the policy it will increase by 10% (1.1)
         */
        private void PremiumClaims()
        {
            foreach (DateTime claimDate in claimDates)
            {
                int years = startDate.Year - claimDate.Year;
                if (startDate.Month < claimDate.Month || (startDate.Month == claimDate.Month && startDate.Day < claimDate.Day))
                {

                    years--;

                }

                if (years >= 0 && years <= 1)
                {
                    percentage *= 1.2;
                }
                if (years >= 2 && years <= 5)
                {
                    percentage *= 1.1;
                }
            }
        }

        //Performs a check to see whether the youngest driver is between 21-15, or above 26 at start date of policy.
        //Other validation methods will ensure drivers below 21 and 75 can not be entered.
        private bool YoungestDriverCheck(List<Driver> drivers, DateTime startDate)
        {
            bool discount = true;
            int youngest = 100, age = 0;
            foreach (Driver driver in driver)
            {
                age = driver.CalculateAge(startDate);
                if (youngest > age)
                {
                    youngest = age;
                }
            }
            if (youngest >= 21 && youngest <= 25)
            {
                discount = false;
            }
            return discount;
        }

        //Adds the selected claim date to a list, and prompts the user with how many they still have to enter.
        //When user inputs all dates, form returns to default
        private void cmdClaimDate_Click(object sender, EventArgs e)
        {
            claimDates.Add(dtpClaimDate.Value.Date);
            remainingClaims--;
            MessageBox.Show("You have successfully entered date of claim.\nYou have " + remainingClaims + " claims remaining.");

            dtpClaimDate.Value = DateTime.Today;

            if (remainingClaims == 0)
            {
                HideClaimEntry();
                ResetFields();
            }
        }


        //Shows the interface that allows entry of claim dates
        private void ShowClaimEntry()
        {
            cmdEnter.Visible = false;
            cmdEnter.Hide();
            cmdPremium.Visible = false;
            cmdPremium.Hide();
            cmdClaimDate.Visible = true;
            cmdClaimDate.Show();
            lblClaimDate.Visible = true;
            lblClaimDate.Show();
            dtpClaimDate.Visible = true;
            dtpClaimDate.Show();
            lblClaimDate.Text = "Please enter the date of the claims(s)";
        }

        //Hides the interface that allows entry of claim dates
        private void HideClaimEntry()
        {
            cmdEnter.Visible = true;
            cmdEnter.Show();
            cmdPremium.Visible = true;
            cmdPremium.Show();
            cmdClaimDate.Visible = false;
            cmdClaimDate.Hide();
            lblClaimDate.Visible = false;
            lblClaimDate.Hide();
            dtpClaimDate.Visible = false;
            dtpClaimDate.Hide();
            lblClaimDate.Visible = false;
            lblClaimDate.Hide();
        }

        //Adds a string to the decline message for having drivers outside of age limits
        private string DeclineMessageAge()
        {
            string message = "";
            foreach (Driver driver in driver)
            {
                int age;
                age = driver.CalculateAge(startDate);
                if (age < 21)
                {
                    //message Age of Youngest Driver + drivers[driverCount-1].Name
                    message += "Age of Youngest Driver: " + driver.Name + "\n";
                }
                if (age > 75)
                {
                    //message Age of Oldest Driver: + drivers[driverCount-1].Name
                    message += "Age of Oldest Driver: " + driver.Name + "\n";
                }
            }
            return message;
        }

        //Adds string to decline message for too many specific driver claims
        private string DeclineMessageDriverClaims()
        {
            string message = "";
            foreach (Driver driver in driver)
            {
                if (driver.NumberOfClaims > 2)
                {
                    message += "Driver has more than 2 claims: " + driver.Name + "\n";
                }
            }
            return message;
        }

        //Adds string to decline message for too many policy claims
        private string DeclineMessageTotalClaims()
        {
            string message = "";
            if (totalPolicyClaims > 3)
            {
                message += "Policy has more than 3 claims.";
            }
            return message;
        }





        //Ensures the user does not input a future date for a date of birth
        private void dtpDOB_ValueChanged(object sender, EventArgs e)
        {
            if (dtpDOB.Value.Date > DateTime.Today)
            {
                MessageBox.Show("Drivers DOB can not be in the future.");
                dtpDOB.Value = (DateTime.Today);
            }
        }

        //Only allows the user to see the enter button when a name is in the textbox
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (txtName.Text == "" || driverCount == 5)
            {
                cmdEnter.Visible = false;
                cmdEnter.Hide();
            }
            else
            {
                cmdEnter.Visible = true;
                cmdEnter.Show();
            }
        }

        //Validates the date of a claim, as the date could not be in the future.
        private void dtpClaimDate_ValueChanged(object sender, EventArgs e)
        {
            if (dtpClaimDate.Value.Date > DateTime.Today)
            {
                MessageBox.Show("You can not have a claim date in the future");
                dtpClaimDate.Value = (DateTime.Today);
            }
        }

        //Resets all data entry objects
        private void ResetFields()
        {
            txtName.ResetText();
            dtpDOB.Value = DateTime.Today;
            lstClaims.ClearSelected();
            optChauffeur.Checked = false;
            optAccountant.Checked = false;
        }
    }
}

