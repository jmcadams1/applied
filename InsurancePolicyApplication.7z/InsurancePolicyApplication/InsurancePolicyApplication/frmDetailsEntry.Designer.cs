﻿namespace InsurancePolicyApplication
{
    partial class frmEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDriverNumber = new System.Windows.Forms.Label();
            this.cmdEnter = new System.Windows.Forms.Button();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblOcupation = new System.Windows.Forms.Label();
            this.lblClaims = new System.Windows.Forms.Label();
            this.optAccountant = new System.Windows.Forms.RadioButton();
            this.optChauffeur = new System.Windows.Forms.RadioButton();
            this.lstClaims = new System.Windows.Forms.ListBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.cmdPremium = new System.Windows.Forms.Button();
            this.dtpClaimDate = new System.Windows.Forms.DateTimePicker();
            this.lblClaimDate = new System.Windows.Forms.Label();
            this.cmdClaimDate = new System.Windows.Forms.Button();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(422, 105);
            this.txtName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(132, 20);
            this.txtName.TabIndex = 0;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(211, 33);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(177, 13);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Motor Insurance Premium Calculator";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(69, 112);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name";
            // 
            // lblDriverNumber
            // 
            this.lblDriverNumber.AutoSize = true;
            this.lblDriverNumber.Location = new System.Drawing.Point(69, 487);
            this.lblDriverNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDriverNumber.Name = "lblDriverNumber";
            this.lblDriverNumber.Size = new System.Drawing.Size(194, 13);
            this.lblDriverNumber.TabIndex = 3;
            this.lblDriverNumber.Text = "You have entered details for 0/5 drivers";
            // 
            // cmdEnter
            // 
            this.cmdEnter.Location = new System.Drawing.Point(454, 487);
            this.cmdEnter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmdEnter.Name = "cmdEnter";
            this.cmdEnter.Size = new System.Drawing.Size(100, 23);
            this.cmdEnter.TabIndex = 5;
            this.cmdEnter.Text = "Enter Details";
            this.cmdEnter.UseVisualStyleBackColor = true;
            this.cmdEnter.Visible = false;
            this.cmdEnter.Click += new System.EventHandler(this.cmdEnter_Click);
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(69, 147);
            this.lblAge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(66, 13);
            this.lblAge.TabIndex = 6;
            this.lblAge.Text = "Date of Birth";
            // 
            // lblOcupation
            // 
            this.lblOcupation.AutoSize = true;
            this.lblOcupation.Location = new System.Drawing.Point(69, 193);
            this.lblOcupation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOcupation.Name = "lblOcupation";
            this.lblOcupation.Size = new System.Drawing.Size(62, 13);
            this.lblOcupation.TabIndex = 7;
            this.lblOcupation.Text = "Occupation";
            // 
            // lblClaims
            // 
            this.lblClaims.AutoSize = true;
            this.lblClaims.Location = new System.Drawing.Point(69, 242);
            this.lblClaims.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblClaims.Name = "lblClaims";
            this.lblClaims.Size = new System.Drawing.Size(131, 13);
            this.lblClaims.TabIndex = 8;
            this.lblClaims.Text = "Number of previous claims";
            // 
            // optAccountant
            // 
            this.optAccountant.AutoSize = true;
            this.optAccountant.Location = new System.Drawing.Point(422, 192);
            this.optAccountant.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optAccountant.Name = "optAccountant";
            this.optAccountant.Size = new System.Drawing.Size(80, 17);
            this.optAccountant.TabIndex = 11;
            this.optAccountant.Text = "Accountant";
            this.optAccountant.UseVisualStyleBackColor = true;
            this.optAccountant.CheckedChanged += new System.EventHandler(this.optAccountant_CheckedChanged);
            // 
            // optChauffeur
            // 
            this.optChauffeur.AutoSize = true;
            this.optChauffeur.Location = new System.Drawing.Point(321, 192);
            this.optChauffeur.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.optChauffeur.Name = "optChauffeur";
            this.optChauffeur.Size = new System.Drawing.Size(71, 17);
            this.optChauffeur.TabIndex = 12;
            this.optChauffeur.Text = "Chauffeur";
            this.optChauffeur.UseVisualStyleBackColor = true;
            this.optChauffeur.CheckedChanged += new System.EventHandler(this.optChauffeur_CheckedChanged);
            // 
            // lstClaims
            // 
            this.lstClaims.FormatString = "N0";
            this.lstClaims.FormattingEnabled = true;
            this.lstClaims.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.lstClaims.Location = new System.Drawing.Point(422, 242);
            this.lstClaims.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lstClaims.Name = "lstClaims";
            this.lstClaims.Size = new System.Drawing.Size(132, 82);
            this.lstClaims.TabIndex = 14;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(354, 143);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 20);
            this.dtpDOB.TabIndex = 16;
            this.dtpDOB.ValueChanged += new System.EventHandler(this.dtpDOB_ValueChanged);
            // 
            // cmdPremium
            // 
            this.cmdPremium.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cmdPremium.Location = new System.Drawing.Point(421, 540);
            this.cmdPremium.Name = "cmdPremium";
            this.cmdPremium.Size = new System.Drawing.Size(132, 23);
            this.cmdPremium.TabIndex = 17;
            this.cmdPremium.Text = "Calculate Premium";
            this.cmdPremium.UseVisualStyleBackColor = true;
            this.cmdPremium.Visible = false;
            this.cmdPremium.Click += new System.EventHandler(this.cmdPremium_Click);
            // 
            // dtpClaimDate
            // 
            this.dtpClaimDate.Location = new System.Drawing.Point(354, 381);
            this.dtpClaimDate.Name = "dtpClaimDate";
            this.dtpClaimDate.Size = new System.Drawing.Size(200, 20);
            this.dtpClaimDate.TabIndex = 18;
            this.dtpClaimDate.Visible = false;
            this.dtpClaimDate.ValueChanged += new System.EventHandler(this.dtpClaimDate_ValueChanged);
            // 
            // lblClaimDate
            // 
            this.lblClaimDate.AutoSize = true;
            this.lblClaimDate.Location = new System.Drawing.Point(69, 381);
            this.lblClaimDate.Name = "lblClaimDate";
            this.lblClaimDate.Size = new System.Drawing.Size(35, 13);
            this.lblClaimDate.TabIndex = 19;
            this.lblClaimDate.Text = "label1";
            this.lblClaimDate.Visible = false;
            // 
            // cmdClaimDate
            // 
            this.cmdClaimDate.Location = new System.Drawing.Point(478, 433);
            this.cmdClaimDate.Name = "cmdClaimDate";
            this.cmdClaimDate.Size = new System.Drawing.Size(75, 23);
            this.cmdClaimDate.TabIndex = 20;
            this.cmdClaimDate.Text = "Enter Date";
            this.cmdClaimDate.UseVisualStyleBackColor = true;
            this.cmdClaimDate.Visible = false;
            this.cmdClaimDate.Click += new System.EventHandler(this.cmdClaimDate_Click);
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(422, 33);
            this.lblStartDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(35, 13);
            this.lblStartDate.TabIndex = 21;
            this.lblStartDate.Text = "label1";
            // 
            // frmEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 602);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.cmdClaimDate);
            this.Controls.Add(this.lblClaimDate);
            this.Controls.Add(this.dtpClaimDate);
            this.Controls.Add(this.cmdPremium);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.lstClaims);
            this.Controls.Add(this.optChauffeur);
            this.Controls.Add(this.optAccountant);
            this.Controls.Add(this.lblClaims);
            this.Controls.Add(this.lblOcupation);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.cmdEnter);
            this.Controls.Add(this.lblDriverNumber);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtName);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Premium Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDriverNumber;
        private System.Windows.Forms.Button cmdEnter;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblOcupation;
        private System.Windows.Forms.Label lblClaims;
        private System.Windows.Forms.RadioButton optAccountant;
        private System.Windows.Forms.RadioButton optChauffeur;
        private System.Windows.Forms.ListBox lstClaims;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Button cmdPremium;
        private System.Windows.Forms.DateTimePicker dtpClaimDate;
        private System.Windows.Forms.Label lblClaimDate;
        private System.Windows.Forms.Button cmdClaimDate;
        private System.Windows.Forms.Label lblStartDate;
    }
}

